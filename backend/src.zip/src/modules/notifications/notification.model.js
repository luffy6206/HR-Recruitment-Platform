import mongoose from "mongoose";

const notificationSchema =
  new mongoose.Schema(
    {
      userId: {
        type:
          mongoose.Schema.Types.ObjectId,

        ref: "User",

        required: true,
      },

      recipientUserId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },

      candidateId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Candidate",
      },

      title: {
        type: String,

        required: true,
      },

      message: {
        type: String,

        required: true,
      },

      type: {
        type: String,

        enum: [
          "FOLLOW_UP",
          "INTERVIEW",
          "TASK",
          "ASSIGNMENT",
          "SYSTEM",
        ],

        default: "SYSTEM",
      },

      isRead: {
        type: Boolean,

        default: false,
      },
    },
    {
      timestamps: true,
    }
  );

notificationSchema.index({
  recipientUserId: 1,
  userId: 1,
  isRead: 1,
});

export default mongoose.model(
  "Notification",
  notificationSchema
);