import Notification from "./notification.model.js";

const notificationQuery = (userId) => ({
  $or: [
    { recipientUserId: userId },
    { userId },
  ],
});

export const createNotification =
  async ({
    userId,
    recipientUserId,
    candidateId,
    title,
    message,
    type,
  }) => {
    return Notification.create({
      userId,
      recipientUserId: recipientUserId ?? userId,
      candidateId,
      title,
      message,
      type,
    });
  };

export const getNotifications =
  async (userId) => {
    return Notification.find(notificationQuery(userId)).sort({
      createdAt: -1,
    });
  };

export const markAsRead =
  async (id, userId) => {
    return Notification.findOneAndUpdate(
      {
        _id: id,
        ...notificationQuery(userId),
      },
      {
        isRead: true,
      },
      {
        new: true,
      }
    );
  };

export const markAllRead =
  async (userId) => {
    return Notification.updateMany(notificationQuery(userId), {
      isRead: true,
    });
  };

export const deleteNotification =
  async (id, userId) => {
    return Notification.findOneAndDelete({
      _id: id,
      ...notificationQuery(userId),
    });
  };

export const clearNotifications =
  async (userId) => {
    return Notification.deleteMany(notificationQuery(userId));
  };