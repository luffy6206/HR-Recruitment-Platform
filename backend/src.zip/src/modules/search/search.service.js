import Candidate from "../candidates/candidate.model.js";
import Interview from "../interviews/interview.model.js";
import Task from "../tasks/task.model.js";

export const globalSearch =
  async (params) => {
    const { q } = params;
    const searchTerm = String(q ?? "").trim();

    if (!searchTerm) {
      return [];
    }

    const regex = { $regex: searchTerm, $options: "i" };

    const candidateFilter = {
      isDeleted: false,
      $or: [
        { name: regex },
        { code: regex },
        { candidateCode: regex },
        { email: regex },
        { phone: regex },
        { category: regex },
        { "aiAnalysis.skills": regex },
      ],
    };

    const candidateResults = await Candidate.find(candidateFilter)
      .limit(5)
      .sort({ createdAt: -1 })
      .populate("assignedHR", "name")
      .select("name code email phone category assignedHR");

    const interviewResults = await Interview.aggregate([
      {
        $lookup: {
          from: "candidates",
          localField: "candidateId",
          foreignField: "_id",
          as: "candidate",
        },
      },
      { $unwind: "$candidate" },
      {
        $lookup: {
          from: "users",
          localField: "candidate.assignedHR",
          foreignField: "_id",
          as: "assignedHR",
        },
      },
      {
        $unwind: {
          path: "$assignedHR",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          $or: [
            { status: regex },
            { "candidate.name": regex },
            { "assignedHR.name": regex },
          ],
        },
      },
      { $sort: { createdAt: -1 } },
      { $limit: 5 },
      {
        $project: {
          candidateName: "$candidate.name",
          status: 1,
          interviewType: 1,
          assignedHRName: "$assignedHR.name",
        },
      },
    ]);

    const taskResults = await Task.aggregate([
      {
        $lookup: {
          from: "candidates",
          localField: "candidateId",
          foreignField: "_id",
          as: "candidate",
        },
      },
      { $unwind: "$candidate" },
      {
        $lookup: {
          from: "users",
          localField: "assignedBy",
          foreignField: "_id",
          as: "assignedBy",
        },
      },
      {
        $unwind: {
          path: "$assignedBy",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          $or: [
            { title: regex },
            { "candidate.name": regex },
            { "assignedBy.name": regex },
          ],
        },
      },
      { $sort: { createdAt: -1 } },
      { $limit: 5 },
      {
        $project: {
          title: 1,
          candidateName: "$candidate.name",
          assignedByName: "$assignedBy.name",
        },
      },
    ]);

    const results = [
      ...candidateResults.map((candidate) => ({
        type: "CANDIDATE",
        id: candidate._id?.toString(),
        title: candidate.name,
        subtitle: `${candidate.code ?? ""}${candidate.code ? " • " : ""}${candidate.category ?? ""}`,
        path: `/candidates/${candidate._id}`,
      })),
      ...interviewResults.map((item) => ({
        type: "INTERVIEW",
        id: item._id?.toString(),
        title: `${item.candidateName} - ${item.status}`,
        subtitle: item.assignedHRName ? `Assigned HR: ${item.assignedHRName}` : `Type: ${item.interviewType}`,
        path: "/interviews",
      })),
      ...taskResults.map((task) => ({
        type: "TASK",
        id: task._id?.toString(),
        title: task.title,
        subtitle: `${task.candidateName ?? ""}${task.candidateName ? " • " : ""}Assigned by ${task.assignedByName ?? "System"}`,
        path: "/tasks",
      })),
    ];

    return results;
  };